OTA Runtime Check 1.1.0 for 260507 and 20260903.
Extract to USB root and approve execution in NEMESIS after a normal head-unit restart.
Send the new KeyBORD-OTA-Runtime folder privately.
NEMESIS success means a report was saved. Review the report and log for runtime evidence.
