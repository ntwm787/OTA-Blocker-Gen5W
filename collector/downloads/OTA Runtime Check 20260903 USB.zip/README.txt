OTA runtime check for 20260903.
Extract at USB root and approve execution in NEMESIS after a normal head-unit restart.
ZIP the new KeyBORD-OTA-Runtime folder and return it privately.
NEMESIS success means a report was saved. Inspect the report and log for runtime evidence.
